﻿using BiblioGo.Application.Exceptions;
using BiblioGo.Application.Users.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BiblioGo.Application.Users.Validators
{
    public static class RegisterUserValidator
    {
        private const int MinPasswordLength = 8;
        private const int MaxEmailLength = 254;
        private const int MinNameLength = 2;
        private const int MaxNameLength = 50;


        public static string? Validate(RegisterUserCommand command)
        {
            return ValidateEmail(command.Email)
                ?? ValidatePassword(command.Password)
                ?? ValidateName(command.FirstName, "Ім'я")
                ?? ValidateName(command.LastName, "Прізвище")
                ?? ValidatePhone(command.Phone);
        }
        private static string? ValidateEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return "Email is required";
            if (email.Length > MaxEmailLength)
                return $"Email must be at most {MaxEmailLength} characters long";
            var trimmedEmail = email.Trim();
            try
            {
                var addr = new System.Net.Mail.MailAddress(trimmedEmail);
                if (addr.Address != trimmedEmail)
                {
                    return "Invalid email format";
                }
            }
            catch
            {
                return "Invalid email format";
            }
            return null;
        }


        private static string? ValidatePassword(string password)
        {
            if (string.IsNullOrWhiteSpace(password))
                return "Password is required";
            if (password.Length < MinPasswordLength)
                return $"Password must be at least {MinPasswordLength} characters long";
            if (!password.Any(char.IsLetter) || !password.Any(char.IsDigit))
            {
                return "Password must contain at least one letter and one digit";
            }
            return null;    
        }

        private static string? ValidateName(string name, string fieldName)
        {
            if (string.IsNullOrWhiteSpace(name))
                return $"{fieldName} is required";
            if (name.Length < MinNameLength || name.Length > MaxNameLength)
                return $"{fieldName} must be between {MinNameLength} and {MaxNameLength} characters long";
            return null;

        }

        private static string? ValidatePhone(string phone)
        {
            if (string.IsNullOrWhiteSpace(phone))
                return "Phone number is required";

            if (!phone.StartsWith('+'))
                return "Phone number must start with '+'";

            var digits = phone[1..];
            if (digits.Length < 10 || digits.Length > 15 || !digits.All(char.IsDigit))
                return "Phone number must contain between 10 and 15 digits after '+'";
            return null;
        }
    }
}